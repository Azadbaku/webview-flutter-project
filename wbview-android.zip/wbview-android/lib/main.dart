// ignore_for_file: use_key_in_widget_constructors, avoid_unnecessary_containers

import 'dart:async';
import 'dart:developer' as developer;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatefulWidget {
  const MainApp({super.key});

  @override
  State<MainApp> createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> {
  ConnectivityResult _connectionStatus = ConnectivityResult.none;
  final Connectivity _connectivity = Connectivity();
  // ignore: unused_field
  late StreamSubscription<ConnectivityResult> _connectivitySubscription;

  bool isLoading = true;

  bool isError = false;

  WebViewController controller = WebViewController()
    ..setJavaScriptMode(JavaScriptMode.unrestricted)
    ..setBackgroundColor(const Color(0x00000000))
    ..setNavigationDelegate(
      NavigationDelegate(
        onProgress: (int progress) {
          // Update loading bar.

          if (kDebugMode) {
            print('lprogresssing...');
          }
        },
        onPageStarted: (String url) {},
        onPageFinished: (String url) {},
        onWebResourceError: (WebResourceError error) {},
        onNavigationRequest: (NavigationRequest request) {
          // if (request.url.startsWith('https://titu.az/')) {
          //   return NavigationDecision.prevent;
          // }
          return NavigationDecision.navigate;
        },
      ),
    )
    ..loadRequest(Uri.parse('https://titu.az/'));

  startLoading() {
    setState(() {
      isLoading = true;
    });
  }

  finishLoading() {
    setState(() {
      isLoading = false;
    });
  }

  isErrorStart() {
    setState(() {
      isError = true;
    });
  }

  isErrorEnd() {
    setState(() {
      isError = false;
    });
  }

  @override
  void initState() {
    super.initState();
    initConnectivity();

    _connectivitySubscription =
        _connectivity.onConnectivityChanged.listen(_updateConnectionStatus);
    //   subscription = Connectivity().onConnectivityChanged.listen((ConnectivityResult result) {
    //   // Got a new connectivity status!
    // });

    controller.setNavigationDelegate(NavigationDelegate(
      onProgress: (progress) {
        startLoading();
      },
      onPageFinished: (url) {
        if (kDebugMode) {
          print(url);
        }
        if (isError) {}
        finishLoading();
        isErrorEnd();
      },
      onWebResourceError: (error) {
        if (error.errorCode == -10) {
          isErrorStart();
        } else {
          isErrorEnd();
        }
        if (kDebugMode) {
          print(error.errorCode);
        }
      },
    ));
  }

  @override
  dispose() {
    super.dispose();
  }

  // Platform messages are asynchronous, so we initialize in an async method.
  Future<void> initConnectivity() async {
    late ConnectivityResult result;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      result = await _connectivity.checkConnectivity();
    } on PlatformException catch (e) {
      developer.log('Couldn\'t check connectivity status', error: e);
      return;
    }

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.
    if (!mounted) {
      return Future.value(null);
    }

    return _updateConnectionStatus(result);
  }

  Future<void> _updateConnectionStatus(ConnectivityResult result) async {
    setState(() {
      _connectionStatus = result;

      if (_connectionStatus.name == "none") {
      } else {
        controller.reload();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Ferma",
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        extendBody: true,

        // appBar: AppBar(centerTitle: true, backgroundColor: Color.fromARGB(255, 224, 72, 38), title:  const Text("Ferma"),),
        body: _connectionStatus.name == "none"
            ? Container(child: const NoInternetView())
            : isError
                ? ErrorView(controller: controller, callBack: (val) {})
                : Column(
                    // fit: StackFit.passthrough,
                    // clipBehavior: Clip.hardEdge,
                    // alignment: Alignment.center,
                    children: [
                      const SizedBox(height: 35.0),
                      isLoading
                          ? const LinearProgressIndicator()
                          : const SizedBox(),
                      Expanded(
                        child: WebViewWidget(controller: controller),
                      ),
                    ],
                  ),
      ),
    );
  }
}

class NoInternetView extends StatefulWidget {
  const NoInternetView({super.key});

  @override
  State<NoInternetView> createState() => _NoInternetViewState();
}

class _NoInternetViewState extends State<NoInternetView> {
  @override
  Widget build(BuildContext context) {
    return Center(child: Container(child: const Text('İnternet bağlantısı yoxdur')));
  }
}

// ignore: must_be_immutable
class ErrorView extends StatefulWidget {
  ErrorView({Key? key, required this.controller, required this.callBack});

  WebViewController controller;
  // final controller;

  final Function(String val) callBack;

  @override
  State<ErrorView> createState() => _ErrorViewState();
}

class _ErrorViewState extends State<ErrorView> {
  @override
  Widget build(BuildContext context) {
    return Center(
        child: Container(
      child: Column(
        children: [
          const Text("Xəta baş verdi"),
          InkWell(
              onTap: () {
                widget.controller.canGoBack();
                widget.callBack('homePage');
              },
              child: const Text("Ana səhifəyə dön")),
        ],
      ),
    ));
  }
}
