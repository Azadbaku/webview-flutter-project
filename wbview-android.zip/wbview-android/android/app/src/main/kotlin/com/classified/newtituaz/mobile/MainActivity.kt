package com.classified.newtituaz.mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
